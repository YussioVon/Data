#! /usr/bin/env python
# -*-coding:utf-8 -*
# @Time : 2021/7/20 8:52
# @Author :Yussio
# @FileName : getData
import re
from time import sleep

import chardet
import paramiko
import web
urls = (
    '/index', 'index',
    '/getData','getData'
)

admin = web.template.render('static/')

class index:
    def GET(self):
        try:
            return admin.index()
        finally:
            with open('error.txt','w') as f:
                f.write('error')
class getData:

    # 接收数据
    def POST(self):
        servers = {
            '121.4.86.9':'Fyx123...'
        }
        data = web.input(server=None,option=None)
        server = data.server
        option = data.option
        pwd = servers.get(server)
        with open('data.txt', 'w') as f:
            f.write(str(server)+'\n'+str(option))
        host = Linux(server,'root',pwd)
        host.connect()
        host.send(option)
        host.close()
class Linux(object):
    def __init__(self, ip, username, password, timeout=30):
        self.ip = ip
        self.username = username
        self.password = password
        self.timeout = timeout
        self.t = ''
        self.chan = ''
        self.try_times = 3

    def connect(self):
        while True:
            try:
                self.t = paramiko.Transport(sock=(self.ip, 22))
                self.t.connect(username=self.username, password=self.password)
                ssh = paramiko.SSHClient()
                ssh_transport = self.t
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                self.chan = self.t.open_session()
                self.chan.settimeout(self.timeout)
                self.chan.get_pty()
                self.chan.invoke_shell()

                print(u'Connect %s Success' % self.ip)
                print(self.chan.recv(65535).decode('utf-8'))
                return
            except Exception as e1:
                if self.try_times != 0:
                    print(u'Connect %s Failed,try again!' % self.ip)
                    self.try_times -= 1
                else:
                    print(u'Connect Failed,program quit!')
                    exit(1)

    def close(self):
        self.chan.close()
        self.t.close()

    def send(self, cmd):
        cmd += '\r'
        p = re.compile(r']#|]$')
        result = ''
        self.chan.send(cmd)
        while True:
            sleep(2)
            ret = self.chan.recv(65535)
            result += ret
            if p.search(ret):
                result = result.encode('ascii').decode('utf-8')
                print(chardet.detect(format(type(result))))
                print(result)
                return result
if __name__ == "__main__":
    app = web.application(urls, globals())
    app.run()